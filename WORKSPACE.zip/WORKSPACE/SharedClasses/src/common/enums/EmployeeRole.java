package common.enums;

public enum EmployeeRole {
	REPRESENTATIVE, MANAGER
}
