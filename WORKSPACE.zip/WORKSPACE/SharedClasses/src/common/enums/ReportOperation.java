package common.enums;

import java.io.Serializable;

public enum ReportOperation implements Serializable {
    GET_TIME_REPORT,
    GET_SUBSCRIBER_REPORT
}
