package common.enums;

public enum ReservationType {
	ADVANCE,
	WALKIN 
}
