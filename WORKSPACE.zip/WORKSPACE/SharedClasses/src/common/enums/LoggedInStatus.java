package common.enums;

public enum LoggedInStatus {
    NOT_LOGGED_IN,
    SUBSCRIBER,
    REPRESENTATIVE,
    MANAGER
}